import { FuseNavigation } from '@fuse/types';
console.log('hola');

export const navigation = [];

    
    // {
    //     id       : '',
    //     title    : '',
    //     translate: '',
    //     type     : 'group',
    //     icon     : 'apps',
    //     children : [
    //         {
    //             id       : 'dashboards',
    //             title    : 'Dashboards',
    //             translate: 'NAV.DASHBOARDS',
    //             type     : 'collapsable',
    //             icon     : 'dashboard',
    //             children : [
    //                 {
    //                     id   : 'analytics',
    //                     title: 'Analytics',
    //                     type : 'item',
    //                     url  : '/apps/dashboards/analytics'
    //                 },
    //                 {
    //                     id   : 'project',
    //                     title: 'Project',
    //                     type : 'item',
    //                     url  : '/apps/dashboards/project'
    //                 }
    //             ]
    //         },
    //         {
    //             id       : 'Admin',
    //             title    : 'Admin',
    //             translate: 'NAV.ADMIN',
    //             type     : 'collapsable',
    //             icon     : 'dashboard',
    //             children : [
    //                 {
    //                     id   : 'Usuarios',
    //                     title: 'Lista de Usuarios',
    //                     type : 'item',
    //                     url  : '/apps/admin/usuarios'
    //                 },
    //                 {
    //                     id   : 'Comercios',
    //                     title: 'Lista de Comercios',
    //                     type : 'item',
    //                     url  : '/apps/admin/comercios'
    //                 }
    //             ]
    //         }
    //     ]
    // }
//];
