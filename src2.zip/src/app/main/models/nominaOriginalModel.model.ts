export class NominaOriginalModel {
    id?:string;
    transactionid:string;
    date:string;
    username:string;
    account:string;
    currency:string;
    amount_usd:string;
    merchant:string;
    customer_name:string;
    account_type:string;
    account_numer:string;
    dni:string;
    department:string;
    cci_numb:string;
    reference:string;
    kycyn:string;
    correo:string;
    celular:string;
    numLine:string;

    constructor(
        public _id?: string,
        public _transactionid?: string,
        public _date?: string,
        public _username?: string,
        public _account?: string,
        public _currency?: string,
        public _amount_usd?: string,
        public _merchant?: string,
        public _customer_name?: string,
        public _account_type?: string,
        public _account_numer?: string,
        public _dni?: string,
        public _department?: string,
        public _cci_numb?: string,
        public _reference?: string,
        public _kycyn?: string,
        public _correo?: string,
        public _celular?: string,
        public _numLine?: string
        
    ) { 
        this.id             = _id;
        this.transactionid  = _transactionid;
        this.date           = _date;
        this.username       = _username;
        this.account        = _account;
        this.currency       = _currency;
        this.amount_usd     = _amount_usd;
        this.merchant       = _merchant;
        this.customer_name  = _customer_name;
        this.account_type   = _account_type;
        this.account_numer  = _account_numer;
        this.dni            = _dni;
        this.department     = _department;
        this.cci_numb       = _cci_numb;
        this.reference      = _reference;
        this.kycyn          = _kycyn;
        this.correo         = _correo;
        this.celular        = _celular;
        this.numLine        = _numLine;

    }
}
