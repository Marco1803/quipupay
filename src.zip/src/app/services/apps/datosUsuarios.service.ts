export class DatoUsuario {
    email: string;
    username: string;
    idinstitucion: string;
    idperfil: string;
    nombres: string;
    apellidos: string;
    nrodocumento: string;
    tipodocumento:string;
    genero: string;
    identificador:string;
}