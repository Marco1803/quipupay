export class NewPasswordUser {
    username: string;
    existingPassword: string;
    password: string;
}