export const environment = {
    production: true,
    hmr       : false,
    cognitoPool: {
        region: 'us-west-2',
        UserPoolId: "us-west-2_oUDeQcE5u",
        ClientId: "1g9usum5nc2ohe2f9m8h7gq4bo"
    }    
};
